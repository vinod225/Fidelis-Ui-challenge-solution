import { DashboardServiceService } from './../Services/dashboard-service.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  filterResults: boolean = false;
  totalCount: number = 0;
  LowSeverityCount: number = 0;
  data: any;
  highSeverityCount: number=0;
  mediumSeverityCount:number=0;
  caCount: number=0;
  usCount: number=0;
  geCount: number =0;
  ausCount: number =0;
  httpCount: number = 0;
  ftpCount: number = 0;
  tlsCount: number = 0;
  stmpCount: number = 0;
  firstCount: number=0;
  secondCount: number=0;
  thirdCount: number=0;
  fourthCount: number=0;
  severityList: any;
  ipList:any;
  protocalList: any;
  countryList: any;
  displayfilterOptions: boolean = false;
  selectedArray: any[] = [];
  constructor(private dashboardService: DashboardServiceService) { }

  ngOnInit(): void {
   this.getData();
  }

  public getData():void{
    this.dashboardService.getJSON().subscribe(data => {
      this.data= data;
      this.loadData();
  });
  }

  public severity():void{
    const lowSeverityList = this.data.filter((item: { Severity: string; })=> {return item.Severity ==='Low' });
    console.log(lowSeverityList);
    const highSeverityList = this.data.filter((item: { Severity: string; })=> {return item.Severity ==='High' });
    const mediumSeverityList = this.data.filter((item: { Severity: string; })=> {return item.Severity ==='Medium' });
    this.severityList = 
    this.data.filter( (thing: { Severity: any; }, i: any, arr: any[]) => arr.findIndex(t => t.Severity === thing.Severity) === i);
    console.log( this.severityList);
    this.LowSeverityCount = lowSeverityList.length;
    this.highSeverityCount = highSeverityList.length;
    this.mediumSeverityCount = mediumSeverityList.length;
    const severityCountList = [{count:this.LowSeverityCount, Value:'Low'},
    {count:this.mediumSeverityCount,Value:'Medium' }, {count:this.highSeverityCount, Value:'High'}];
    this.severityList.map((item: any) => {
      severityCountList.map((item1)=>{
        if(item.Severity=== item1.Value){
          item.sevCount = item1.count;
        }
      })
         return {...item};
    });
    console.log(this.severityList)
    
  }
  public clientIp():void{
    const firstList = this.data.filter((item: { ClientIP: string; })=> {return item.ClientIP ==='43.172.24.178' });
    const secondList = this.data.filter((item: { ClientIP: string; })=> {return item.ClientIP ==='66.78.200.140' });
    const thridList = this.data.filter((item: { ClientIP: string; })=> {return item.ClientIP ==='155.175.121.134' });
    const fourthList = this.data.filter((item: { ClientIP: string; })=> {return item.ClientIP ==='97.28.36.120' });
    this.ipList = 
    this.data.filter( (thing: { ClientIP: any; }, i: any, arr: any[]) => arr.findIndex(t => t.ClientIP === thing.ClientIP) === i);
    this.firstCount = firstList.length;
    this.secondCount = secondList.length;
    this.thirdCount = thridList.length;
    this.fourthCount = fourthList.length;
    const ipCountList = [{count:this.thirdCount, value:"155.175.121.134"}, 
     {count:this.secondCount, value:"66.78.200.140"}, 
     {count:this.firstCount, value:"43.172.24.178"}, {count:this.fourthCount, value:"97.28.36.120"}];
    this.ipList.map((item: any) => {
      ipCountList.map((item2)=>{
        if(item.ClientIP=== item2.value){
          item.ipCount = item2.count
        }
      })
         
         return {...item};
    });
  }
  public portocal():void{
    const httpList = this.data.filter((item: { Protocol: string; })=> {return item.Protocol ==='HTTP' });
    const ftpList = this.data.filter((item: { Protocol: string; })=> {return item.Protocol ==='FTP' });
    const tlsList = this.data.filter((item: { Protocol: string; })=> {return item.Protocol ==='TLS' });
    const smtpList = this.data.filter((item: { Protocol: string; })=> {return item.Protocol ==='SMTP' });
    this.protocalList = 
    this.data.filter( (thing: { Protocol: any; }, i: any, arr: any[]) => arr.findIndex(t => t.Protocol === thing.Protocol) === i);
    this.httpCount = httpList.length;
    this.ftpCount = ftpList.length;
    this.tlsCount = tlsList.length;
    this.stmpCount = smtpList.length;
    const protocalCount = [{count:this.httpCount, value:'HTTP'},
     {count:this.ftpCount, value:'FTP'}, {count:this.tlsCount, value:'TLS'}, {count:this.stmpCount, value:'SMTP'}];
    this.protocalList.map((item: any) => {
      protocalCount.map((item3)=>{
        if(item.Protocol=== item3.value){
          item.pCount = item3.count
        }
      }); 
         return {...item};
    });
  }
  public clientCountry():void{
    const caList = this.data.filter((item: { ClientCountry: string; })=> {return item.ClientCountry ==='Canada' });
    const usList = this.data.filter((item: { ClientCountry: string; })=> {return item.ClientCountry ==='United States' });
    const geList = this.data.filter((item: { ClientCountry: string; })=> {return item.ClientCountry ==='Germany' });
    const ausList = this.data.filter((item: { ClientCountry: string; })=> {return item.ClientCountry ==='Australia' });
    this.countryList = 
    this.data.filter( (thing: { ClientCountry: any; }, i: any, arr: any[]) => arr.findIndex(t => t.ClientCountry === thing.ClientCountry) === i);
    this.caCount = caList.length;
    this.usCount = usList.length;
    this.geCount = geList.length;
    this.ausCount = ausList.length;
    const clientCountryCount = [{count:this.caCount,value:'Canada' }, 
    {count:this.usCount, value:'United States'}, {count:this.geCount, value:'Germany'}, {count:this.ausCount, value:'Australia'}]
    this.countryList.map((item: any) => {
      clientCountryCount.map((item4)=>{
        if(item.ClientCountry=== item4.value){
          item.coCount = item4.count;
        }
      })
          return {...item};
    });
    console.log(this.countryList);
  }
  public loadData():void{
    this.totalCount = this.data.length;
      this.severity();
      this.clientCountry();
      this.portocal();
      this.clientIp();
      console.log(this.totalCount);
  }
  public filter(value:any, type:string):void{
      console.log('this is value' + value);
      console.log('Type -' + type);
      const filteredList = []
      this.displayfilterOptions = true;
      this.selectedArray.push({key:type, value:value});
      console.log(this.selectedArray);
      for (const item of this.data){
        if (item[type] === value){
          filteredList.push(item);
          this.data = filteredList;
        }
      }
      this.loadData();
      console.log(this.data);
  }

 public resetFilter():void{
    this.selectedArray = [];
    this.displayfilterOptions = false;
    this.getData();
  }
  
 

}
