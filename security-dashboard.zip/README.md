Thanks for sending the code challenge and I used angular for completing the task.
Please follow below steps for installing and running the application.
1. npm install -g @angular/cli (for installing cli globally).
2. In side project run npm install (This will add node modules).
3. Run ng s or ng serve to start the project.
4. Open browser and use the port number displayed after ng s.
5. Already defalut redirection to dashbaord is handled.
